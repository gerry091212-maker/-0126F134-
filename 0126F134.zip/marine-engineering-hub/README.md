# Marine Engineering Hub｜船舶輪機工程知識庫

## 專案簡介
這是一個使用 HTML、CSS、JavaScript 製作的船舶輪機工程教學網站，整理主機、輔機、輪機系統與中英文專業術語。適合作為輪機系學生的入門知識庫。

## 專案特色
- 五大導覽區域：首頁、船舶主機、船舶輔機、輪機系統、專業術語。
- 9 個設備及系統主題，含工作原理及檢查重點。
- 中英文術語對照與即時搜尋。
- 響應式版面，支援手機與桌面。
- 使用 `AGENTS.md` 規範後續 AI 開發，方便重複使用與擴充。

## 檔案結構
```
marine-engineering-hub/
├── index.html     # 網站首頁及版面結構
├── styles.css     # 全站視覺與響應式樣式
├── app.js         # 知識資料、分類、搜尋及互動
├── AGENTS.md      # AI 開發規範
└── README.md      # 專案說明與部署指南
```

## 如何使用
直接使用瀏覽器開啟 `index.html` 即可。無須安裝任何套件。

## GitHub Pages 部署步驟
1. 登入 GitHub，建立新的 **Public** repository，例如 `marine-engineering-hub`。
2. 將上述五個檔案上傳到 repository 的根目錄並 Commit。
3. 進入 **Settings → Pages**。
4. 在 **Build and deployment** 選擇 **Deploy from a branch**。
5. Branch 選擇 **main**、資料夾選擇 **/(root)**，按 **Save**。
6. 等待部署完成後，公開網址通常為 `https://你的帳號.github.io/marine-engineering-hub/`。

## 後續擴充方式
請先閱讀 `AGENTS.md`，再依照 `app.js` 中 `topics` 的既有欄位新增設備。新增的內容會自動出現在對應分類及搜尋結果中。

**示範給 AI 的指令：**
> 請先閱讀 AGENTS.md，依照專案既有規則，新增「熱交換器」教學內容，並確保搜尋與手機版正常運作。

## 使用限制
本網站內容僅供教學，不應作為船舶設備維修或操作的唯一依據。
